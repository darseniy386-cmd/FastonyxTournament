#!/usr/bin/env sh
set -eu
mvn clean package
printf '\nPlugin JAR: target/tournament-1.0.0.jar\n'
