package ru.fastonyx.tournament;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

final class FileConfigurationBackups {
    private final JavaPlugin plugin;
    private final File file;
    FileConfigurationBackups(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "player-backups.yml");
    }

    void load(Map<UUID, TournamentPlugin.Backup> target) {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("players");
        if (root == null) return;
        for (String raw : root.getKeys(false)) {
            try {
                UUID id = UUID.fromString(raw);
                ConfigurationSection s = root.getConfigurationSection(raw);
                if (s == null) continue;
                TournamentPlugin.Backup b = new TournamentPlugin.Backup();
                b.items = itemArray(s.getList("items"));
                b.armor = itemArray(s.getList("armor"));
                b.offhand = s.getItemStack("offhand");
                b.level = s.getInt("level"); b.exp = (float)s.getDouble("exp");
                b.food = s.getInt("food",20); b.health = s.getDouble("health",20);
                b.location = s.getLocation("location");
                b.allowFlight = s.getBoolean("allowFlight");
                b.flySpeed = (float)s.getDouble("flySpeed",0.1); b.walkSpeed = (float)s.getDouble("walkSpeed",0.2);
                target.put(id,b);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Invalid player UUID in player-backups.yml: " + raw);
            }
        }
    }

    void save(Map<UUID, TournamentPlugin.Backup> source) {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID,TournamentPlugin.Backup> entry : source.entrySet()) {
            String path = "players." + entry.getKey(); TournamentPlugin.Backup b = entry.getValue();
            y.set(path + ".items", Arrays.asList(b.items)); y.set(path + ".armor", Arrays.asList(b.armor));
            y.set(path + ".offhand", b.offhand); y.set(path + ".level", b.level); y.set(path + ".exp", b.exp);
            y.set(path + ".food", b.food); y.set(path + ".health", b.health); y.set(path + ".location", b.location);
            y.set(path + ".allowFlight", b.allowFlight); y.set(path + ".flySpeed", b.flySpeed); y.set(path + ".walkSpeed", b.walkSpeed);
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) { plugin.getLogger().severe("Could not save player backups: " + ex.getMessage()); }
    }

    private ItemStack[] itemArray(List<?> list) {
        if (list == null) return new ItemStack[0];
        ItemStack[] result = new ItemStack[list.size()];
        for (int i=0;i<list.size();i++) result[i] = list.get(i) instanceof ItemStack item ? item : null;
        return result;
    }
}
