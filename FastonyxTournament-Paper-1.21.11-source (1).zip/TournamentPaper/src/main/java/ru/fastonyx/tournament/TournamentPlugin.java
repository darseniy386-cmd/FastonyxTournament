package ru.fastonyx.tournament;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scoreboard.*;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class TournamentPlugin extends JavaPlugin implements Listener, TabExecutor {
    private final Map<String, EventData> events = new HashMap<>();
    private final Map<UUID, String> playerEvent = new HashMap<>();
    private final Map<UUID, Backup> backups = new HashMap<>();
    private final Map<UUID, String> pendingConfirm = new HashMap<>();
    private final Set<UUID> internalTeleport = new HashSet<>();
    private final Map<UUID, Scoreboard> oldBoards = new HashMap<>();
    private final Map<UUID, Backup> pendingRespawnBackups = new HashMap<>();
    private FileConfigurationBackups backupStore;

    private static final String PREFIX = "§8[§6Турнир§8] §f";

    @Override public void onEnable() {
        saveDefaultConfig();
        backupStore = new FileConfigurationBackups(this);
        backupStore.load(backups);
        loadEvents();
        Objects.requireNonNull(getCommand("tur")).setExecutor(this);
        Objects.requireNonNull(getCommand("tur")).setTabCompleter(this);
        getServer().getPluginManager().registerEvents(this, this);
        // Recover inventories if the server was restarted while players were registered/in a match.
        for (Player p : Bukkit.getOnlinePlayers()) recoverIfNeeded(p);
        getLogger().info("FastonyxTournament enabled");
    }

    @Override public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (backups.containsKey(p.getUniqueId())) restorePlayer(p, true);
        }
        backupStore.save(backups);
    }

    private void loadEvents() {
        ConfigurationSection root = getConfig().getConfigurationSection("tournaments");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            EventData e = new EventData(key);
            e.registration = s.getBoolean("registration", false);
            e.kit = s.getString("kit", "");
            e.wait = Region.load(s.getConfigurationSection("wait"));
            e.arena = Region.load(s.getConfigurationSection("arena"));
            e.out = Region.load(s.getConfigurationSection("out"));
            for (String id : s.getStringList("participants")) try { e.participants.add(UUID.fromString(id)); } catch (IllegalArgumentException ignored) {}
            // Registrations and active matches are safely cancelled after a restart.
            // Player inventories remain in player-backups.yml and are restored on their next join.
            e.participants.clear(); e.running = false; e.registration = false;
            events.put(key.toLowerCase(Locale.ROOT), e);
            saveEvent(e);
        }
    }

    private void saveEvent(EventData e) {
        String base = "tournaments." + e.name;
        getConfig().set(base + ".registration", e.registration);
        getConfig().set(base + ".kit", e.kit);
        e.wait.save(getConfig(), base + ".wait"); e.arena.save(getConfig(), base + ".arena"); e.out.save(getConfig(), base + ".out");
        getConfig().set(base + ".participants", e.participants.stream().map(UUID::toString).toList());
        saveConfig();
    }

    private boolean admin(CommandSender s) { return s instanceof Player p ? p.isOp() || p.hasPermission("tournament.admin") : true; }
    private void msg(CommandSender s, String text) { s.sendMessage(PREFIX + text); }
    private String key(String s) { return s.toLowerCase(Locale.ROOT); }
    private EventData event(String name) { return events.get(key(name)); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] a) {
        if (a.length == 0) { help(sender); return true; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (sub.equals("join")) {
            if (!(sender instanceof Player p)) { msg(sender, "Только игрок может использовать эту команду."); return true; }
            if (a.length < 2) { msg(sender, "Использование: /tur join <название>"); return true; }
            joinPrompt(p, a[1]); return true;
        }
        if (sub.equals("leave")) {
            if (!(sender instanceof Player p)) { msg(sender, "Только игрок может использовать эту команду."); return true; }
            leave(p, true); return true;
        }
        if (!admin(sender)) { msg(sender, "Эта команда доступна только оператору."); return true; }
        if (sub.equals("region") && a.length == 3 && a[1].equalsIgnoreCase("apply")) {
            EventData e = getOrCreate(a[2]); applyDefaultRegions(e);
            msg(sender,"Три территории из сохранённых точек применены к турниру «" + e.name + "». Проверь, что все точки установлены в правильном мире.");
            return true;
        }
        if (sub.equals("pos")) {
            if (!(sender instanceof Player p) || a.length != 3) { msg(sender, "Использование: /tur pos <wait|arena|out> <1|2>"); return true; }
            setPoint(p, a[1], a[2]); return true;
        }
        if (sub.equals("reg") && a.length >= 3) {
            EventData e = getOrCreate(a[2]);
            if (a[1].equalsIgnoreCase("start")) { if (e.running) { msg(sender,"Турнир уже идёт."); return true; } e.registration = true; saveEvent(e); broadcast(e,"Регистрация открыта! /tur join " + e.name); }
            else if (a[1].equalsIgnoreCase("stop")) { e.registration = false; saveEvent(e); broadcast(e,"Регистрация закрыта."); }
            else msg(sender,"Использование: /tur reg <start|stop> <название>");
            return true;
        }
        if (sub.equals("start") && a.length >= 3) { startMatch(sender, a[1], a[2]); return true; }
        if (sub.equals("finish") && a.length >= 2) { finish(event(a[1]), sender, "Турнир завершён администратором."); return true; }
        if (sub.equals("kit") && a.length >= 2) {
            if (a[1].equalsIgnoreCase("create")) {
                if (!(sender instanceof Player p)) { msg(sender,"Команда доступна только игроку."); return true; }
                String kitName = a.length >= 3 ? a[2] : "default";
                getConfig().set("kits." + key(kitName), Arrays.asList(p.getInventory().getContents()));
                getConfig().set("kit-armor." + key(kitName), Arrays.asList(p.getInventory().getArmorContents()));
                getConfig().set("kit-offhand." + key(kitName), p.getInventory().getItemInOffHand());
                saveConfig(); msg(sender,"Кит «" + kitName + "» сохранён.");
            } else if (a[1].equalsIgnoreCase("set") && a.length >= 3) {
                EventData e = getOrCreate(a[2]);
                if (a.length < 4) { msg(sender,"Использование: /tur kit set <турнир> <название-кита>"); return true; }
                String kit = key(a[3]);
                if (!getConfig().contains("kits." + kit)) { msg(sender,"Такого кита нет. Создай: /tur kit create " + kit); return true; }
                e.kit = kit; saveEvent(e); msg(sender,"Для турнира «" + e.name + "» установлен кит «" + kit + "».");
            } else msg(sender,"Использование: /tur kit create [название] | /tur kit set <турнир> <кит>");
            return true;
        }
        help(sender); return true;
    }

    private void help(CommandSender s) {
        msg(s,"Команды игроков: /tur join <название>, /tur leave");
        if (admin(s)) {
            msg(s,"Админ: /tur pos <wait|arena|out> <1|2>, затем /tur region apply <название>");
            msg(s,"Админ: /tur reg <start|stop> <название>");
            msg(s,"Админ: /tur start <1v1|2v2|3v3> <название>, /tur finish <название>");
            msg(s,"Админ: /tur kit create [название], /tur kit set <турнир> <кит>");
        }
    }

    private EventData getOrCreate(String name) { return events.computeIfAbsent(key(name), k -> new EventData(name)); }

    private void setPoint(Player p, String area, String point) {
        if (!Set.of("wait","arena","out").contains(area.toLowerCase(Locale.ROOT)) || !Set.of("1","2").contains(point)) { msg(p,"Использование: /tur pos <wait|arena|out> <1|2>"); return; }
        // Region coordinates are stored per tournament. This command sets the default template used by all events.
        Location l = p.getLocation();
        getConfig().set("default-regions." + area.toLowerCase(Locale.ROOT) + ".p" + point + ".world", l.getWorld().getName());
        getConfig().set("default-regions." + area.toLowerCase(Locale.ROOT) + ".p" + point + ".x", l.getBlockX());
        getConfig().set("default-regions." + area.toLowerCase(Locale.ROOT) + ".p" + point + ".y", l.getBlockY());
        getConfig().set("default-regions." + area.toLowerCase(Locale.ROOT) + ".p" + point + ".z", l.getBlockZ());
        saveConfig();
        msg(p,"Точка " + point + " территории " + area + " сохранена. После установки обеих точек выполни /tur region apply <название> (см. README).");
    }

    private void applyDefaultRegions(EventData e) {
        e.wait = defaultRegion("wait"); e.arena = defaultRegion("arena"); e.out = defaultRegion("out"); saveEvent(e);
    }
    private Region defaultRegion(String name) {
        ConfigurationSection s = getConfig().getConfigurationSection("default-regions." + name);
        if (s == null) return new Region();
        return Region.fromConfig(s);
    }

    private void joinPrompt(Player p, String name) {
        EventData e = event(name);
        if (e == null) { msg(p,"Турнир не найден."); return; }
        if (!e.registration || e.running) { msg(p,"Регистрация на этот турнир сейчас закрыта."); return; }
        if (playerEvent.containsKey(p.getUniqueId())) { msg(p,"Ты уже участвуешь в турнире."); return; }
        pendingConfirm.put(p.getUniqueId(), key(name));
        p.sendMessage(Component.text("Внимание! При участии в турнире твой инвентарь, броня и опыт будут временно сохранены и очищены. После выхода они будут восстановлены.", NamedTextColor.YELLOW));
        p.sendMessage(Component.text(" "));
        p.sendMessage(Component.text("[ПРОДОЛЖИТЬ]", NamedTextColor.GREEN).clickEvent(ClickEvent.runCommand("/tur _confirm")).hoverEvent(HoverEvent.showText(Component.text("Сохранить вещи и войти в турнир")))
                .append(Component.text("   ")).append(Component.text("[ОТМЕНА]", NamedTextColor.RED).clickEvent(ClickEvent.runCommand("/tur _cancel")).hoverEvent(HoverEvent.showText(Component.text("Отменить запись")))));
    }

    private void confirm(Player p) {
        String name = pendingConfirm.remove(p.getUniqueId()); if (name == null) { msg(p,"Нет ожидающего подтверждения."); return; }
        EventData e = event(name);
        if (e == null || !e.registration || e.running) { msg(p,"Регистрация уже закрыта."); return; }
        if (!valid(e.wait)) { msg(p,"Администратор ещё не настроил территорию ожидания."); return; }
        backups.put(p.getUniqueId(), Backup.capture(p)); backupStore.save(backups);
        p.getInventory().clear(); p.getInventory().setArmorContents(new ItemStack[4]); p.getInventory().setItemInOffHand(null); p.setExp(0); p.setLevel(0);
        e.participants.add(p.getUniqueId()); playerEvent.put(p.getUniqueId(), name); saveEvent(e);
        teleportToRegion(p, e.wait); msg(p,"Ты записан на турнир «" + e.name + "». Удачи!");
    }

    private void leave(Player p, boolean restore) {
        String n = playerEvent.remove(p.getUniqueId()); pendingConfirm.remove(p.getUniqueId());
        if (n == null) { msg(p,"Ты не участвуешь в турнире."); return; }
        EventData e = event(n);
        if (e != null) { e.participants.remove(p.getUniqueId()); e.teamA.remove(p.getUniqueId()); e.teamB.remove(p.getUniqueId()); saveEvent(e); if (e.running) checkWinner(e); }
        if (restore) restorePlayer(p, true);
        msg(p,"Ты покинул турнир.");
    }

    private void startMatch(CommandSender sender, String format, String name) {
        EventData e = event(name);
        if (e == null) { msg(sender,"Турнир не найден. Сначала открой регистрацию."); return; }
        if (e.running) { msg(sender,"Турнир уже запущен."); return; }
        if (events.values().stream().anyMatch(other -> other.running)) { msg(sender,"На сервере уже проводится другой PvP-матч."); return; }
        if (!e.registration) { msg(sender,"Сначала открой регистрацию: /tur reg start " + name); return; }
        if (!valid(e.wait) || !valid(e.arena) || !valid(e.out)) { msg(sender,"Не настроены все 3 территории. Смотри README."); return; }
        int size = switch (format.toLowerCase(Locale.ROOT)) { case "1v1" -> 1; case "2v2" -> 2; case "3v3" -> 3; default -> 0; };
        if (size == 0) { msg(sender,"Формат должен быть 1v1, 2v2 или 3v3."); return; }
        List<UUID> players = new ArrayList<>(e.participants); players.removeIf(id -> Bukkit.getPlayer(id) == null);
        if (players.size() != size * 2) { msg(sender,"Для " + format + " нужно ровно " + (size * 2) + " игроков онлайн. Сейчас: " + players.size() + "."); return; }
        Collections.shuffle(players); e.teamA.clear(); e.teamB.clear();
        e.teamA.addAll(players.subList(0,size)); e.teamB.addAll(players.subList(size,size*2));
        e.running = true; e.registration = false; e.format = format;
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id); if (p == null) continue;
            p.setHealth(20); p.setFoodLevel(20); p.setFireTicks(0); p.setFallDistance(0);
            giveKit(p,e.kit); setTeamBoard(p, e.teamA.contains(id) ? "§cКРАСНЫЕ §r" : "§9СИНИЕ §r", e.teamA.contains(id) ? ChatColor.RED : ChatColor.BLUE);
            teleportToRegion(p,e.arena);
        }
        saveEvent(e); broadcast(e,"Бой " + format + " начался! Красная команда против синей.");
    }

    private void giveKit(Player p, String kit) {
        if (kit == null || kit.isBlank() || !getConfig().contains("kits." + kit)) return;
        p.getInventory().clear();
        List<?> contents = getConfig().getList("kits." + kit); if (contents != null) { ItemStack[] arr = contents.stream().map(x -> x instanceof ItemStack i ? i : null).toArray(ItemStack[]::new); p.getInventory().setContents(arr); }
        List<?> armor = getConfig().getList("kit-armor." + kit); if (armor != null) { ItemStack[] arr = armor.stream().map(x -> x instanceof ItemStack i ? i : null).toArray(ItemStack[]::new); p.getInventory().setArmorContents(arr); }
        Object off = getConfig().get("kit-offhand." + kit); if (off instanceof ItemStack item) p.getInventory().setItemInOffHand(item);
        p.updateInventory();
    }

    private void setTeamBoard(Player p, String prefix, ChatColor color) {
        Scoreboard old = p.getScoreboard(); oldBoards.put(p.getUniqueId(), old);
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        String teamName = color == ChatColor.RED ? "tur_red" : "tur_blue";
        Team team = board.getTeam(teamName); if (team == null) team = board.registerNewTeam(teamName);
        team.setPrefix(prefix); team.setColor(color); team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.ALWAYS); team.setAllowFriendlyFire(false);
        team.addEntry(p.getName()); p.setScoreboard(board);
    }
    private void clearTeamBoard(Player p) {
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        for (String t : List.of("tur_red","tur_blue")) { Team team = board.getTeam(t); if (team != null) team.removeEntry(p.getName()); }
        Scoreboard old = oldBoards.remove(p.getUniqueId()); if (old != null) p.setScoreboard(old);
    }

    private void checkWinner(EventData e) {
        if (!e.running) return;
        e.teamA.removeIf(id -> Bukkit.getPlayer(id) == null); e.teamB.removeIf(id -> Bukkit.getPlayer(id) == null);
        if (e.teamA.isEmpty() || e.teamB.isEmpty()) {
            Set<UUID> winners = e.teamA.isEmpty() ? e.teamB : e.teamA;
            String side = e.teamA.isEmpty() ? "Синяя" : "Красная";
            broadcast(e, winners.isEmpty() ? "Турнир завершён без победителей." : "Победила " + side + " команда!");
            for (UUID id : new HashSet<>(e.participants)) {
                Player p = Bukkit.getPlayer(id); if (p == null) continue;
                clearTeamBoard(p);
                if (winners.contains(id)) msg(p,"Поздравляем! Ты победитель турнира.");
                else if (valid(e.out)) teleportToRegion(p,e.out);
                restorePlayer(p,true);
                playerEvent.remove(id);
            }
            e.participants.clear(); e.teamA.clear(); e.teamB.clear(); e.running = false; e.registration = false; saveEvent(e);
        }
    }

    private void finish(EventData e, CommandSender sender, String reason) {
        if (e == null) { msg(sender,"Турнир не найден."); return; }
        broadcast(e,reason);
        for (UUID id : new HashSet<>(e.participants)) {
            Player p = Bukkit.getPlayer(id); if (p != null) { clearTeamBoard(p); restorePlayer(p,true); msg(p,"Турнир завершён."); }
            playerEvent.remove(id);
        }
        e.participants.clear(); e.teamA.clear(); e.teamB.clear(); e.running=false; e.registration=false; saveEvent(e); msg(sender,"Турнир «"+e.name+"» завершён.");
    }

    private void restorePlayer(Player p, boolean teleportBack) {
        UUID id = p.getUniqueId(); Backup b = backups.get(id); if (b == null) return;
        if (p.isDead()) {
            pendingRespawnBackups.put(id, b);
            return;
        }
        backups.remove(id); pendingRespawnBackups.remove(id);
        b.restore(p, false);
        if (teleportBack && b.location != null && b.location.getWorld() != null) {
            internalTeleport.add(id);
            p.teleportAsync(b.location).whenComplete((ok, err) -> internalTeleport.remove(id));
        }
        backupStore.save(backups);
    }
    private void recoverIfNeeded(Player p) {
        if (backups.containsKey(p.getUniqueId())) { restorePlayer(p,true); msg(p,"Твои вещи восстановлены после перезапуска сервера."); }
    }
    private void teleportToRegion(Player p, Region r) {
        Location l = r.randomSafeLocation(); if (l == null) { msg(p,"Не удалось найти безопасную точку телепортации в регионе."); return; }
        internalTeleport.add(p.getUniqueId()); p.teleportAsync(l).whenComplete((ok, err) -> internalTeleport.remove(p.getUniqueId()));
    }
    private boolean valid(Region r) { return r != null && r.valid(); }
    private void broadcast(EventData e, String text) { for (UUID id : e.participants) { Player p=Bukkit.getPlayer(id); if(p!=null) msg(p,text); } }
    private boolean inAnyTournamentRegion(Location l) {
        for (EventData e : events.values()) if ((valid(e.wait)&&e.wait.contains(l)) || (valid(e.arena)&&e.arena.contains(l)) || (valid(e.out)&&e.out.contains(l))) return true;
        return false;
    }
    private boolean inArenaForMatch(Player p) {
        String n=playerEvent.get(p.getUniqueId()); EventData e=n==null?null:event(n);
        return e!=null && e.running && (e.teamA.contains(p.getUniqueId())||e.teamB.contains(p.getUniqueId())) && valid(e.arena) && e.arena.contains(p.getLocation());
    }

    @EventHandler public void onCommandPreprocess(PlayerCommandPreprocessEvent ev) {
        Player p=ev.getPlayer(); String raw=ev.getMessage().toLowerCase(Locale.ROOT);
        if (raw.equals("/tur _confirm") || raw.equals("/tournament _confirm")) { ev.setCancelled(true); confirm(p); return; }
        if (raw.equals("/tur _cancel") || raw.equals("/tournament _cancel")) { ev.setCancelled(true); pendingConfirm.remove(p.getUniqueId()); msg(p,"Запись отменена."); return; }
        if (playerEvent.containsKey(p.getUniqueId()) && !p.isOp() && !p.hasPermission("tournament.admin")) {
            String root=raw.split(" ")[0]; if (!root.equals("/tur") && !root.equals("/tournament")) { ev.setCancelled(true); msg(p,"Во время турнира доступны только /tur leave."); }
        }
    }
    @EventHandler public void onBreak(BlockBreakEvent e) { if (!e.getPlayer().isOp() && inAnyTournamentRegion(e.getBlock().getLocation())) { e.setCancelled(true); msg(e.getPlayer(),"Здесь нельзя ломать блоки."); } }
    @EventHandler public void onPlace(BlockPlaceEvent e) { if (!e.getPlayer().isOp() && inAnyTournamentRegion(e.getBlock().getLocation())) { e.setCancelled(true); msg(e.getPlayer(),"Здесь нельзя ставить блоки."); } }
    @EventHandler public void onTeleport(PlayerTeleportEvent e) {
        Player p=e.getPlayer(); if (internalTeleport.remove(p.getUniqueId())) return;
        if (!p.isOp() && (inAnyTournamentRegion(e.getFrom()) || inAnyTournamentRegion(e.getTo()))) { e.setCancelled(true); msg(p,"Телепортация на территории турнира запрещена."); }
    }
    @EventHandler public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker=null;
        if (e.getDamager() instanceof Player pl) attacker=pl;
        else if (e.getDamager() instanceof org.bukkit.entity.Projectile pr && pr.getShooter() instanceof Player pl) attacker=pl;
        boolean victimJoined=playerEvent.containsKey(victim.getUniqueId());
        boolean attackerJoined=attacker!=null && playerEvent.containsKey(attacker.getUniqueId());
        if (victimJoined || attackerJoined) {
            if (attacker==null || !attackerJoined || !victimJoined || !inArenaForMatch(attacker) || !inArenaForMatch(victim)) { e.setCancelled(true); return; }
            EventData ev=event(playerEvent.get(attacker.getUniqueId()));
            if (ev==null || !Objects.equals(playerEvent.get(attacker.getUniqueId()),playerEvent.get(victim.getUniqueId())) || (ev.teamA.contains(attacker.getUniqueId())==ev.teamA.contains(victim.getUniqueId()))) e.setCancelled(true);
        }
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) {
        Player p=e.getEntity(); String n=playerEvent.get(p.getUniqueId()); if(n==null)return;
        EventData ev=event(n); if(ev==null)return;
        e.setKeepInventory(true); e.getDrops().clear(); e.setDroppedExp(0);
        Bukkit.getScheduler().runTask(this,()->{
            if (ev.teamA.contains(p.getUniqueId())) ev.teamA.remove(p.getUniqueId());
            if (ev.teamB.contains(p.getUniqueId())) ev.teamB.remove(p.getUniqueId());
            clearTeamBoard(p);
            p.setFireTicks(0);
            msg(p,"Ты выбыл из турнира."); checkWinner(ev);
        });
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        Player p=e.getPlayer(); pendingConfirm.remove(p.getUniqueId()); pendingRespawnBackups.remove(p.getUniqueId());
        String n=playerEvent.remove(p.getUniqueId());
        if(n!=null){ EventData ev=event(n); if(ev!=null){ev.teamA.remove(p.getUniqueId());ev.teamB.remove(p.getUniqueId());ev.participants.remove(p.getUniqueId());saveEvent(ev);if(ev.running)checkWinner(ev);} }
    }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Backup pending = pendingRespawnBackups.get(id);
        if (pending != null) {
            if (pending.location != null && pending.location.getWorld() != null) e.setRespawnLocation(pending.location);
            Bukkit.getScheduler().runTaskLater(this, () -> {
                Player p = Bukkit.getPlayer(id); Backup b = pendingRespawnBackups.remove(id);
                if (p != null && b != null) { backups.remove(id); b.restore(p, false); backupStore.save(backups); }
            }, 1L);
            return;
        }
        String n = playerEvent.get(id); EventData ev = n == null ? null : event(n);
        if (ev != null && ev.running && !ev.teamA.contains(id) && !ev.teamB.contains(id) && valid(ev.out)) {
            Location target = ev.out.randomSafeLocation(); if (target != null) e.setRespawnLocation(target);
        }
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) { Bukkit.getScheduler().runTask(this,()->recoverIfNeeded(e.getPlayer())); }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        if(a.length==1)return filter(List.of("join","leave","reg","start","finish","kit","pos","region"),a[0]);
        if(a.length==2 && a[0].equalsIgnoreCase("region"))return filter(List.of("apply"),a[1]);
        if(a.length==3 && a[0].equalsIgnoreCase("region"))return filter(new ArrayList<>(events.keySet()),a[2]);
        if(a.length==2 && a[0].equalsIgnoreCase("reg"))return filter(List.of("start","stop"),a[1]);
        if(a.length==2 && a[0].equalsIgnoreCase("start"))return filter(List.of("1v1","2v2","3v3"),a[1]);
        if(a.length==2 && a[0].equalsIgnoreCase("pos"))return filter(List.of("wait","arena","out"),a[1]);
        if(a.length==3 && a[0].equalsIgnoreCase("pos"))return filter(List.of("1","2"),a[2]);
        if(a.length==3 && (a[0].equalsIgnoreCase("reg")||a[0].equalsIgnoreCase("start")||a[0].equalsIgnoreCase("finish")))return filter(new ArrayList<>(events.keySet()),a[2]);
        return List.of();
    }
    private List<String> filter(List<String> src,String token){return src.stream().filter(x->x.toLowerCase(Locale.ROOT).startsWith(token.toLowerCase(Locale.ROOT))).toList();}

    private static final class EventData {
        final String name; boolean registration,running; String kit="",format=""; Region wait=new Region(),arena=new Region(),out=new Region();
        final Set<UUID> participants=new LinkedHashSet<>(),teamA=new LinkedHashSet<>(),teamB=new LinkedHashSet<>();
        EventData(String n){name=n;}
    }
    private static final class Region {
        String world1,world2; int x1,y1,z1,x2,y2,z2;
        boolean valid(){return world1!=null&&world2!=null&&world1.equals(world2);}
        boolean contains(Location l){return valid()&&l.getWorld()!=null&&l.getWorld().getName().equals(world1)&&l.getBlockX()>=Math.min(x1,x2)&&l.getBlockX()<=Math.max(x1,x2)&&l.getBlockY()>=Math.min(y1,y2)&&l.getBlockY()<=Math.max(y1,y2)&&l.getBlockZ()>=Math.min(z1,z2)&&l.getBlockZ()<=Math.max(z1,z2);}
        Location randomSafeLocation(){if(!valid())return null;World w=Bukkit.getWorld(world1);if(w==null)return null;int x=(Math.min(x1,x2)+Math.max(x1,x2))/2,z=(Math.min(z1,z2)+Math.max(z1,z2))/2;int y=Math.max(y1,y2)+1;Location l=new Location(w,x+0.5,y,z+0.5);if(l.getBlock().isPassable()&&l.clone().add(0,1,0).getBlock().isPassable())return l;int top=w.getHighestBlockYAt(x,z)+1;return new Location(w,x+0.5,top,z+0.5);}
        void save(org.bukkit.configuration.file.FileConfiguration c,String path){c.set(path+".world1",world1);c.set(path+".world2",world2);c.set(path+".x1",x1);c.set(path+".y1",y1);c.set(path+".z1",z1);c.set(path+".x2",x2);c.set(path+".y2",y2);c.set(path+".z2",z2);}
        static Region load(ConfigurationSection s){if(s==null)return new Region();Region r=new Region();r.world1=s.getString("world1");r.world2=s.getString("world2");r.x1=s.getInt("x1");r.y1=s.getInt("y1");r.z1=s.getInt("z1");r.x2=s.getInt("x2");r.y2=s.getInt("y2");r.z2=s.getInt("z2");return r;}
        static Region fromConfig(ConfigurationSection s){Region r=new Region();ConfigurationSection a=s.getConfigurationSection("p1"),b=s.getConfigurationSection("p2");if(a==null||b==null)return r;r.world1=a.getString("world");r.world2=b.getString("world");r.x1=a.getInt("x");r.y1=a.getInt("y");r.z1=a.getInt("z");r.x2=b.getInt("x");r.y2=b.getInt("y");r.z2=b.getInt("z");return r;}
    }
    static final class Backup {
        ItemStack[] items,armor; ItemStack offhand; int level,food; float exp; double health; Location location; boolean allowFlight; float flySpeed,walkSpeed;
        static Backup capture(Player p){Backup b=new Backup();b.items=p.getInventory().getContents().clone();b.armor=p.getInventory().getArmorContents().clone();b.offhand=p.getInventory().getItemInOffHand().clone();b.level=p.getLevel();b.exp=p.getExp();b.food=p.getFoodLevel();b.health=p.getHealth();b.location=p.getLocation().clone();b.allowFlight=p.getAllowFlight();b.flySpeed=p.getFlySpeed();b.walkSpeed=p.getWalkSpeed();return b;}
        void restore(Player p,boolean back){p.getInventory().clear();p.getInventory().setContents(items);p.getInventory().setArmorContents(armor);p.getInventory().setItemInOffHand(offhand);p.setLevel(level);p.setExp(exp);p.setFoodLevel(food);p.setHealth(Math.max(1,Math.min(p.getMaxHealth(),health)));p.setAllowFlight(allowFlight);p.setFlySpeed(flySpeed);p.setWalkSpeed(walkSpeed);p.updateInventory();}
    }
}
