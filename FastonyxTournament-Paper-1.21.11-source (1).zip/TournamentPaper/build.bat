@echo off
mvn clean package
if errorlevel 1 exit /b 1
echo.
echo Plugin JAR: target\tournament-1.0.0.jar
